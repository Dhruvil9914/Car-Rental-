﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtCoustmerNameKM = New System.Windows.Forms.TextBox()
        Me.txtCarMake = New System.Windows.Forms.TextBox()
        Me.txtPhoneNumberKM = New System.Windows.Forms.TextBox()
        Me.txtFinalKM = New System.Windows.Forms.TextBox()
        Me.txtCarModel = New System.Windows.Forms.TextBox()
        Me.txtStartKM = New System.Windows.Forms.TextBox()
        Me.txtCarUse = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.lbltravelledKM = New System.Windows.Forms.Label()
        Me.lblCharge = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btPrint = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.lblCost = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtCoustmerNameKM
        '
        Me.txtCoustmerNameKM.Location = New System.Drawing.Point(124, 110)
        Me.txtCoustmerNameKM.Name = "txtCoustmerNameKM"
        Me.txtCoustmerNameKM.Size = New System.Drawing.Size(193, 22)
        Me.txtCoustmerNameKM.TabIndex = 0
        Me.txtCoustmerNameKM.Text = "Coustmer's name"
        '
        'txtCarMake
        '
        Me.txtCarMake.Location = New System.Drawing.Point(124, 166)
        Me.txtCarMake.Name = "txtCarMake"
        Me.txtCarMake.Size = New System.Drawing.Size(193, 22)
        Me.txtCarMake.TabIndex = 8
        Me.txtCarMake.Text = "Car Make"
        '
        'txtPhoneNumberKM
        '
        Me.txtPhoneNumberKM.Location = New System.Drawing.Point(124, 138)
        Me.txtPhoneNumberKM.Name = "txtPhoneNumberKM"
        Me.txtPhoneNumberKM.Size = New System.Drawing.Size(193, 22)
        Me.txtPhoneNumberKM.TabIndex = 9
        Me.txtPhoneNumberKM.Text = "Phone Number"
        '
        'txtFinalKM
        '
        Me.txtFinalKM.Location = New System.Drawing.Point(124, 250)
        Me.txtFinalKM.Name = "txtFinalKM"
        Me.txtFinalKM.Size = New System.Drawing.Size(193, 22)
        Me.txtFinalKM.TabIndex = 10
        Me.txtFinalKM.Text = "Final Odometer Reading "
        '
        'txtCarModel
        '
        Me.txtCarModel.Location = New System.Drawing.Point(124, 194)
        Me.txtCarModel.Name = "txtCarModel"
        Me.txtCarModel.Size = New System.Drawing.Size(193, 22)
        Me.txtCarModel.TabIndex = 11
        Me.txtCarModel.Text = "Car Model"
        '
        'txtStartKM
        '
        Me.txtStartKM.Location = New System.Drawing.Point(124, 222)
        Me.txtStartKM.Name = "txtStartKM"
        Me.txtStartKM.Size = New System.Drawing.Size(193, 22)
        Me.txtStartKM.TabIndex = 12
        Me.txtStartKM.Text = "Start Odometer Reading "
        '
        'txtCarUse
        '
        Me.txtCarUse.Location = New System.Drawing.Point(124, 278)
        Me.txtCarUse.Name = "txtCarUse"
        Me.txtCarUse.Size = New System.Drawing.Size(193, 22)
        Me.txtCarUse.TabIndex = 13
        Me.txtCarUse.Text = "Number of the day's car use"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(334, 110)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(155, 58)
        Me.btnCalculate.TabIndex = 14
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'lbltravelledKM
        '
        Me.lbltravelledKM.AutoSize = True
        Me.lbltravelledKM.Location = New System.Drawing.Point(561, 110)
        Me.lbltravelledKM.Name = "lbltravelledKM"
        Me.lbltravelledKM.Size = New System.Drawing.Size(130, 17)
        Me.lbltravelledKM.TabIndex = 15
        Me.lbltravelledKM.Text = "Kilometer Travelled"
        '
        'lblCharge
        '
        Me.lblCharge.AutoSize = True
        Me.lblCharge.Location = New System.Drawing.Point(561, 138)
        Me.lblCharge.Name = "lblCharge"
        Me.lblCharge.Size = New System.Drawing.Size(94, 17)
        Me.lblCharge.TabIndex = 16
        Me.lblCharge.Text = "Total Charge "
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(334, 306)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(155, 58)
        Me.btnExit.TabIndex = 17
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btPrint
        '
        Me.btPrint.Location = New System.Drawing.Point(334, 242)
        Me.btPrint.Name = "btPrint"
        Me.btPrint.Size = New System.Drawing.Size(155, 58)
        Me.btPrint.TabIndex = 18
        Me.btPrint.Text = "Print"
        Me.btPrint.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(334, 174)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(155, 58)
        Me.btnClear.TabIndex = 19
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'lblCost
        '
        Me.lblCost.AutoSize = True
        Me.lblCost.Location = New System.Drawing.Point(561, 169)
        Me.lblCost.Name = "lblCost"
        Me.lblCost.Size = New System.Drawing.Size(36, 17)
        Me.lblCost.TabIndex = 20
        Me.lblCost.Text = "Cost"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(981, 687)
        Me.Controls.Add(Me.lblCost)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btPrint)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblCharge)
        Me.Controls.Add(Me.lbltravelledKM)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtCarUse)
        Me.Controls.Add(Me.txtStartKM)
        Me.Controls.Add(Me.txtCarModel)
        Me.Controls.Add(Me.txtFinalKM)
        Me.Controls.Add(Me.txtPhoneNumberKM)
        Me.Controls.Add(Me.txtCarMake)
        Me.Controls.Add(Me.txtCoustmerNameKM)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtCoustmerNameKM As TextBox
    Friend WithEvents txtCarMake As TextBox
    Friend WithEvents txtPhoneNumberKM As TextBox
    Friend WithEvents txtFinalKM As TextBox
    Friend WithEvents txtCarModel As TextBox
    Friend WithEvents txtStartKM As TextBox
    Friend WithEvents txtCarUse As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents lbltravelledKM As Label
    Friend WithEvents lblCharge As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btPrint As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents lblCost As Label
End Class

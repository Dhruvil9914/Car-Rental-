﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim startKM, finalKM, travelledKM, totalCharge As Decimal
        Const flatRate As Decimal = 100
        Const milageRate As Decimal = 0.12
        Const dailyRate As Decimal = 15


        startKM = txtStartKM.Text
        finalKM = txtFinalKM.Text


        travelledKM = finalKM - startKM

        lbltravelledKM.Text = "Kilometer travelled:" & travelledKM

        totalCharge = 100 + (travelledKM * milageRate)

        lblCharge.text = totalCharge



    End Sub
End Class
